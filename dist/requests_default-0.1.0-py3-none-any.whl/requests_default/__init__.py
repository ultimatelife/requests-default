from .requests_default import DefaultSession
